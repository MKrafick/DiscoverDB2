#!/bin/sh
## Author:  M. Krafick | Version 1 | October 3rd, 2018
## Purpose: Entrypoint script for Developer-C docker image.
##          This entrypoint script takes the base installation and applies
##          Db2 configuration changes universal to all environments.
##
## Version: October 3rd, 2018 - Original Build
##
## (3) Variables are defined at container RUN command. (2) used here and (1) exported from this script to DB Config script.
##     - Database name (-e DBNAME='<database name>')
##     - DB2INST1 Password (-e DB2_PASS='<password>')
##     - DBUSER Password (-e USER_PASS='<password>')

## Start Script
echo ""
echo "Script Start: $(date)"
echo ""

## Create Db2 instance ID, group, and create profile.
## The instance .profile must be created before instance creation or the profile is not updated correctly.
echo "Phase 1: ID and group creation"

grep db2iadm1 /etc/group > /dev/null 2>&1
if [ $? -ne 0 ]; then
 echo "DB2 admin group doesn't exist, creating group DB2IADM1."
 groupadd db2iadm1
 else
 echo "DB2IADM1 group exists, skipping ..."
fi

grep dbuser /etc/group > /dev/null 2>&1
if [ $? -ne 0 ]; then
 echo "DBUSER ID and Group do not exist, creating."
 groupadd dbuser
 useradd -g dbuser dbuser
 if [[ ! -z $USER_PASS ]]; then
  echo "Setting DBUSER Password ..."
  echo "dbuser:$USER_PASS" | chpasswd
  if [ $? -ne 0 ]; then
   echo "DBUSER Password was not set. Probably due to complexity or rule violation. Manual set required. Proceeding..."
  fi
 else
 echo "No password for DBUSER was given, bypassing password change."
 fi

 else
 echo "DBUSER ID and Group group exists, skipping ..."
fi


echo ""
echo  "Phase 2: Instance .profile creation"
id db2inst1 > /dev/null 2>&1
if [ $? -ne 0 ]; then
  echo "DB2 Instance (db2inst1) does not exist, creating."
  useradd -G db2iadm1 db2inst1 2>/dev/null #Redirect error, will complain about ID already having a home directory from dockerfile creation.
  useradd -G db2iadm1 db2fenc1
  touch /home/db2inst1/.profile
  chown db2inst1:db2iadm1 /home/db2inst1/.profile
  if [[ ! -z $DB2_PASS ]]; then
   echo "Setting DB2INST1 Password ..."
   echo "db2inst1:$DB2_PASS" | chpasswd
   if [ $? -ne 0 ]; then
    echo "DB2INST1 Password was not set. Probably due to complexity or rule violation. Manual set required. Proceeding..."
   fi
  else
  echo "No password for DB2INST1 was given, bypassing password change."
 fi
 else
  echo "DB2 Instance (db2inst1) already exists, skipping ..."
fi

## Adjust filesystem permissions as needed
echo ""
echo "Phase 3: Adjust filesystem ownership and permission if necessary"

ls -ld /home/db2inst1 /data /db_logs /db_backup /db2diag | awk '{print $1, $3, $4, $9}'| while read PERM OWNER GROUP DIR
do

 if [[ $PERM != 'drwxrwxr-x' ]]
   then
    echo "Adjusting permissions for $DIR."
    chmod -R 775 $DIR
 fi

 if ! [[ "$OWNER" == "db2inst1" || "$GROUP" == "db2iadm1" ]]
   then
    echo "Adjusting ownership for $DIR."
    chown -R db2inst1:db2iadm1 $DIR
 fi

done


## Configure Instance .profile for usablity
echo ""
echo "Phase 4: DB2 Instance .profile usability changes"

PROF_CONFIG=$(cat /home/db2inst1/.profile | grep 'set -o vi')
if [[ "$PROF_CONFIG" != "set -o vi" ]]; then
   echo "DB2 Instance .profile usablility settings missing, adjusting."
   echo "set -o vi" >> /home/db2inst1/.profile
   echo "export PS1='\$(whoami)@\$(hostname -s):\$PWD $ '" >> /home/db2inst1/.profile
   printf '%s\n' 'if [ -f ~/.profile ]; then' '. ~/.profile' 'fi' > /home/db2inst1/.bash_profile
  else
   echo "DB2 Instance .profile exists, skipping ..."
fi

## Instance Creation
echo ""
echo "Phase 5: Create Instance if it doesn't exist"

if [ ! -e /home/db2inst1/sqllib/db2nodes.cfg ]
  then
   echo "DB2 Instance (db2inst1) has not been created, creating instance."
   cd /opt/ibm/db2/V11.1/instance
   /bin/sh -c  "./db2icrt -u db2fenc1 db2inst1"
  else
   echo "DB2 Instance has already been created, skipping ..."
   echo "db2c_db2inst1 50000/tcp" >> /etc/services
fi


## Straighten out /etc/services if ports missing.
## Ports may get trashed on container restarts
echo ""
echo "Phase 6: Repair /etc/services ports if needed."
if [[ `grep -c db2inst1 /etc/services` < 1 ]]
  then
   echo "Ports are missing from services file, adding."
   echo "DB2_db2inst1 60000/tcp" >> /etc/services
   echo "DB2_db2inst1_1 60001/tcp" >> /etc/services
   echo "DB2_db2inst1_2 60002/tcp" >> /etc/services
   echo "DB2_db2inst1_3 60003/tcp" >> /etc/services
   echo "DB2_db2inst1_4 60004/tcp" >> /etc/services
   echo "DB2_db2inst1_END 60005/tcp" >> /etc/services
  else
   echo "Proper ports detected in /etc/services, skipping ..."
fi

echo ""
echo "Phase 7: Clean up memory segments from previous abend."
## Clean up memory segments from abnormal shutdown, etc
if [ -f /home/db2inst1/sqllib/bin/ipclean ];
   then
    echo "Issuing IPCLEAN to remove rogue memory segments from abnormal shutdown."
    su - db2inst1 -c "/home/db2inst1/sqllib/bin/ipclean"
   else
    echo "IPCLEAN command not detected, can't proactively clear memory segments, skipping ..."
fi


## Instance Level and Environment Specific Settings (Universal)
echo ""
echo "Phase 8: Apply universal database configuration changes"

DIAG_SET=$(su - db2inst1 -c "db2 get dbm cfg | grep '(DIAGPATH)'" | awk '{print $7}')
if [ "$DIAG_SET" != "/db2diag/" ]; then
  echo "DB2 Error log path is not set, updating DBM CFG."
  su - db2inst1 -c "db2 -v UPDATE DBM CFG USING DIAGPATH /db2diag IMMEDIATE"
 else
  echo "DIAGPATH is set already, skipping ..."
fi

MON_BUFF=$(su - db2inst1 -c "db2 get dbm cfg | grep 'DFT_MON_BUFPOOL'" | awk '{print $5}')
if [ "$MON_BUFF" != "ON" ]; then
  echo "DFT_MON_BUFPOOL is not set, updating DBM cfg."
  su - db2inst1 -c "db2 -v UPDATE DBM CFG USING DFT_MON_BUFPOOL ON IMMEDIATE"
 else
  echo "DFT_MON_BUFPOOL is already set, skipping ..."
fi

MON_LOCK=$(su - db2inst1 -c "db2 get dbm cfg | grep 'DFT_MON_LOCK'" | awk '{print $4}')
if [ "$MON_LOCK" != "ON" ]; then
  echo "DFT_MON_LOCK is not set, updating DBM cfg."
  su - db2inst1 -c "db2 -v UPDATE DBM CFG USING DFT_MON_LOCK ON IMMEDIATE"
 else
  echo "DFT_MON_LOCK is already set, skipping ..."
fi

MON_SORT=$(su - db2inst1 -c "db2 get dbm cfg | grep 'DFT_MON_SORT'" | awk '{print $4}')
if [ "$MON_SORT" != "ON" ]; then
  echo "DFT_MON_SORT is not set, updating DBM cfg."
  su - db2inst1 -c "db2 -v UPDATE DBM CFG USING DFT_MON_SORT ON IMMEDIATE"
 else
  echo "DFT_MON_SORT is alredy set, skipping ..."
fi

MON_STMT=$(su - db2inst1 -c "db2 get dbm cfg | grep 'DFT_MON_STMT'" | awk '{print $4}')
if [ "$MON_STMT" != "ON" ]; then
  echo "DFT_MON_STMT is not set, updating DBM cfg."
  su - db2inst1 -c "db2 -v UPDATE DBM CFG USING DFT_MON_STMT ON IMMEDIATE"
 else
  echo "DFT_MON_STMT is alredy set, skipping ..."
fi

MON_TABLE=$(su - db2inst1 -c "db2 get dbm cfg | grep 'DFT_MON_TABLE'" | awk '{print $4}')
if [ "$MON_TABLE" != "ON" ]; then
  echo "DFT_MON_TABLE is not set, updating DBM cfg."
  su - db2inst1 -c "db2 -v UPDATE DBM CFG USING DFT_MON_TABLE ON IMMEDIATE"
 else
  echo "DFT_MON_TABLE is alredy set, skipping ..."
fi

MON_TIMESTAMP=$(su - db2inst1 -c "db2 get dbm cfg | grep 'DFT_MON_TIMESTAMP'" | awk '{print $4}')
if [ "$MON_TIMESTAMP" != "ON" ]; then
  echo "DFT_MON_TIMESTAMP is not set, updating DBM cfg."
  su - db2inst1 -c "db2 -v UPDATE DBM CFG USING DFT_MON_TIMESTAMP ON IMMEDIATE"
 else
  echo "DFT_MON_TIMESTAMP is alredy set, skipping ..."
fi

MON_UOW=$(su - db2inst1 -c "db2 get dbm cfg | grep 'DFT_MON_UOW'" | awk '{print $6}')
if [ "$MON_UOW" != "ON" ]; then
  echo "DFT_MON_UOW is not set, updating DBM cfg."
  su - db2inst1 -c "db2 -v UPDATE DBM CFG USING DFT_MON_UOW ON IMMEDIATE"
 else
  echo "DFT_MON_UOW is alredy set, skipping ..."
fi

MON_HEALTH=$(su - db2inst1 -c "db2 get dbm cfg | grep 'HEALTH_MON'" | awk '{print $9}')
if [ "$MON_HEALTH" != "ON" ]; then
  echo "MON_HEALTH is not set, updating DBM cfg."
  su - db2inst1 -c "db2 -v UPDATE DBM CFG USING HEALTH_MON ON IMMEDIATE"
 else
  echo "MON_HEALTH is alredy set, skipping ..."
fi


DATA_FS=$(su - db2inst1 -c "db2 get dbm cfg | grep 'DFTDBPATH'" | awk '{print $6}')
if [ "$DATA_FS" != "/db_data" ]; then
  echo "DFTDBPATH is not set, updating DBM cfg."
  su - db2inst1 -c "db2 -v UPDATE DBM CFG USING DFTDBPATH /db_data IMMEDIATE"
 else
  echo "DFTDBPATH is alredy set, skipping ..."
fi

SVCENAME_VAL=$(su - db2inst1 -c "db2 get dbm cfg | grep 'db2c_db2inst1'" | awk '{print $6}')
if [ "$SVCENAME_VAL" != "db2c_db2inst1" ]; then
  echo "SVCENAME is not set, updating DBM cfg."
  su - db2inst1 -c "db2 -v UPDATE DBM CFG USING SVCENAME db2c_db2inst1 IMMEDIATE"
 else
  echo "SVCENAME is alredy set, skipping ..."
fi

echo ""
echo "Re-calabrating CPUSPEED (Always done on every container start)."
su - db2inst1 -c "db2 -v UPDATE DBM CFG USING CPUSPEED -1"  #No if/then logic, never hurts to update each time


su - db2inst1 -c "db2set -all | grep 'AUTOSTART'"> /dev/null 2>&1
if [ $? -ne 0 ]; then
  echo ""
  echo "Disabling Autorestart."
  su - db2inst1 -c "db2iauto -off db2inst1"
 else
  echo "Autostart is already disabled, skipping ..."
fi

su - db2inst1 -c "db2set -all | grep 'TCPIP'"> /dev/null 2>&1
if [ $? -ne 0 ]; then
 echo ""
  echo "DB2COMM is not set to TCPIP, updating environment registry."
  su - db2inst1 -c "db2set DB2COMM=TCPIP"
 else
  echo "DB2COMM is already set, skipping ..."
fi

su - db2inst1 -c "db2set -all | grep '*'"> /dev/null 2>&1
if [ $? -ne 0 ]; then
  echo""
  echo "DB2_PARALLEL_IO is not set, updating environment registry."
  su - db2inst1 -c "db2set DB2_PARALLEL_IO=*"
 else
  echo "DB2_PARALLEL_IO is already set, skipping ..."
fi

## End Script
echo ""
echo "Script end. Handoff to DB_BUILD: $(date)"

## Apply DB specific changes and build database shell
echo ""
echo "Phase 9: Call DB specific configuration script"

echo "   Exporting database name and type to the environment specific script."
echo "   Calling DB Specific configuration script. View progress within the container - /tmp/DB_BUILD.out."
export DBNAME=$DBNAME
su -m db2inst1 -c "/tmp/DB_BUILD.ksh > /tmp/DB_BUILD.out"

## Command for background to keep container status up
## Note: Use OS log for keep foreground process.
echo ""
echo "Phase 10: Tailing background process to keep container online"

tail -f /var/log/lastlog
